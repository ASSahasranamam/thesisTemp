#ifndef NOKOGIRI_XML_ATTR
#define NOKOGIRI_XML_ATTR

#include <nokogiri.h>

void init_xml_attr();

extern VALUE cNokogiriXmlAttr;
#endif
