module Mathtype3
  class mtef_options < BinData::Record
    
  end
end
