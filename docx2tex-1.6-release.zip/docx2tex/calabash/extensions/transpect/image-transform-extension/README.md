# image-transform-extension
XML Calabash extension to convert images
