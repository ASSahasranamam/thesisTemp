module BinData
  VERSION = "2.3.5"
end
