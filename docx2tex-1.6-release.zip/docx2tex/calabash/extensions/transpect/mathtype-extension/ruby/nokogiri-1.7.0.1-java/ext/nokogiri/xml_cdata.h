#ifndef NOKOGIRI_XML_CDATA
#define NOKOGIRI_XML_CDATA

#include <nokogiri.h>

void init_xml_cdata();

extern VALUE cNokogiriXmlCData;
#endif
