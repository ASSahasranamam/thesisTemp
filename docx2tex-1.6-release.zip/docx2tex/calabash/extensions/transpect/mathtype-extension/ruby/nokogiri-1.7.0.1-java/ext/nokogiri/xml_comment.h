#ifndef NOKOGIRI_XML_COMMENT
#define NOKOGIRI_XML_COMMENT

#include <nokogiri.h>

void init_xml_comment();

extern VALUE cNokogiriXmlComment;
#endif
