#ifndef NOKOGIRI_XML_SCHEMA
#define NOKOGIRI_XML_SCHEMA

#include <nokogiri.h>

void init_xml_schema();

extern VALUE cNokogiriXmlSchema;
#endif
