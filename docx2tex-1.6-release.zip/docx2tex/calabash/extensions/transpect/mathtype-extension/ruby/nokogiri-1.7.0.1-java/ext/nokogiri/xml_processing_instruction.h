#ifndef NOKOGIRI_XML_PROCESSING_INSTRUCTION
#define NOKOGIRI_XML_PROCESSING_INSTRUCTION

#include <nokogiri.h>

void init_xml_processing_instruction();

extern VALUE cNokogiriXmlProcessingInstruction;
#endif
