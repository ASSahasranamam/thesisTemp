module Mathtype
  class RecordChar < BinData::Record; end
  class RecordLine < BinData::Record; end
  class RecordMatrix < BinData::Record; end
  class RecordPile < BinData::Record; end
  class RecordSize < BinData::Record; end
end
